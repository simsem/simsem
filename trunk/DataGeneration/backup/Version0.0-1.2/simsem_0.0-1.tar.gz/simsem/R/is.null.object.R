is.null.object <- function(target) {}
setGeneric("is.null.object")
