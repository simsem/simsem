# simData
# Methods -- simsem package
# A constructor of data object
# Argument:
#	param: 		SimSet of parameter values (or SimModelOut)
# 	n: 			Sample size
# 	misspec : 	SimMisspec for misspecified parameter values
#	equalCon:	Equality constraint
#	conBeforeMis:	TRUE if users wish to constrain parameters before adding misspecification. FALSE if users wish to constrain parameters after adding misspecification
#	misfitBound:	Upper bound of population root mean squared error of approximation (RMSEA; Browne & Cudeck, 1992; Steiger & Lind, 1980) that users wish their model misspecification to be
#	maxDraw:	The maximum number of random drawn parameters and misspecification model until all parameters in the model are eligible (no negative error variance, standardized coefficients over 1).
#	sequential:	If TRUE, use a sequential method to create data such that the data from factor are generated first and apply to a set of equations to obtain the data of indicators. If FALSE, create data directly from model-implied mean and covariance of indicators.
#	facDist:	A SimDataDist for a distribution of factors. Use when sequential is TRUE
#	errorDist:	A SimDataDist for a distribution of measurement errors. Use when sequential is TRUE
#	indDist:	A SimDataDist for a distribution of indicators. Use when sequential is FALSE.
#	indLab:		A vector of indicator names. If not specified, the variables names are y1, y2, ... .
# Author: Sunthud Pornprasertmanit (University of Kansas; psunthud@ku.edu)

setMethod("simData", signature(param="SimSet"), definition=function(param, n, misspec=new("NullSimMisspec"), equalCon=new("NullSimEqualCon"), conBeforeMis=TRUE, misfitBound=new("NullVector"), maxDraw=100, sequential=NA, facDist=new("NullSimDataDist"), errorDist=new("NullSimDataDist"), indDist=new("NullSimDataDist"), indLab=new("NullVector")) {
	modelType <- param@modelType
	if(!(is.na(sequential) | sequential == TRUE | sequential == FALSE)) stop("Please specify NA (to use default), TRUE, or FALSE for the sequential argument")
	if(is.na(sequential)) sequential <- FALSE
	if(!isNullObject(misspec)) {
		if(modelType != misspec@modelType) stop("SimMisspec and SimSet do not have the same tag")
	}
	if(!isNullObject(equalCon)) {
		if(modelType != equalCon@modelType) stop("SimEqualCon and SimSet do not have the same tag")
	}
	if(!isNullObject(misfitBound)) {
		if(length(misfitBound) == 2) {
			if(misfitBound[1] >= misfitBound[2]) stop("The lower bound is higher than the upper bound")
		} else {
			stop("misfitBound must include only two numbers for lower and upper bound")
		}
	}
	if(!isNullObject(errorDist)) {
		if(modelType == "Path" | modelType == "Path.exo") stop("errorDist is not allowed for path analysis model. The distribution of each indicator should be specified in facDist if sequential=TRUE.")
	}
	if(!sequential & !isNullObject(facDist)) stop("facDist is not allowed when using model-implied method in data generation")
	if(!sequential & !isNullObject(errorDist)) stop("errorDist is not allowed when using model-implied method in data generation")
	if(sequential & !isNullObject(indDist)) stop("indDist is not allowed when using sequential method in data generation")
	return(new("SimData", n=n, modelType=modelType, param=param, misspec=misspec,
		equalCon=equalCon, conBeforeMis=conBeforeMis, misfitBound=misfitBound, maxDraw=maxDraw,
		sequential=sequential, facDist=facDist, errorDist=errorDist, indDist=indDist, indLab=indLab))
}
)

setMethod("simData", signature(param="SimModelOut"), definition=function(param, misspec=new("NullSimMisspec"), conBeforeMis=TRUE, misfitBound=new("NullVector"), maxDraw=100, sequential=NA, facDist=new("NullSimDataDist"), errorDist=new("NullSimDataDist"), indDist=new("NullSimDataDist"), usedStd=TRUE) {
	n <- param@n
	modelType <- param@coef@modelType
	equalCon <- param@equalCon
	usedParam <- toSimSet(param, usedStd=usedStd)
	indLab <- param@indLab
	result <- simData(param=usedParam, n=n, misspec=misspec, equalCon=equalCon, conBeforeMis=conBeforeMis, misfitBound=misfitBound, maxDraw=maxDraw, sequential=sequential, facDist=facDist, errorDist=errorDist, indDist=indDist, indLab=indLab) 
	return(result)
}
)
# Additional arguments:
#	usedStd:	If TRUE, use standardized parameters to create new data. If FALSE, use unstandardized one.