adjust.object <- function(target, simDist, position, constant.fixed=TRUE) {}
setGeneric("adjust.object")