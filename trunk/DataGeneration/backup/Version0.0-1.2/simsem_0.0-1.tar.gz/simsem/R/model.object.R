model.object <- function(object, ...) {}
setGeneric("model.object")
