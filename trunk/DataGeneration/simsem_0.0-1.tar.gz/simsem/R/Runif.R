setClass("Runif",
	representation(
		Lower="numeric",
		Upper="numeric"
	)
)
