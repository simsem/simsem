# plotPower
# Methods -- simsem package
# This function will plot sampling distributions of fit indices that visualize power
# Generic Function: plotPower(altObject, nullObject, ...)
# Argument:
#	altObject: 	The object that saves fit indices for alternative hypothesis
#	nullObject:	The object of null hypothesis. It can be vector of cutoffs or raw data of fit indices of null hypothesis.
#	...:			Other arguments such as which fit indices will be used.
# Author: Sunthud Pornprasertmanit (University of Kansas; psunthud@ku.edu)
# Date Modified: October 9, 2011

setMethod("plotPower", signature(altObject="data.frame", nullObject="vector"), definition=function(altObject, nullObject, usedFit=NULL) {
	plotCutoff(altObject, nullObject, usedFit=usedFit)
})
#Arguments: 
#	altObject:		data.frame.c of alternative hypothesis that users wish to plot their sampling distribution
# 	nullObject:	A priori cutoffs for fit indices based on null hypothesis, saved in a vector
#	usedFit:		The name of fit indices that researchers wish to plot
#Description: 	This function will plot alternative sampling distributions with their cutoffs.
#Return: 		NONE. Just plot.
	
setMethod("plotPower", signature(altObject="SimResult", nullObject="vector"), definition=function(altObject, nullObject, usedFit=NULL) {
	plotCutoff(altObject@fit, nullObject, usedFit=usedFit)
})
#Arguments: 
#	altObject:		SimResult.c of alternative hypothesis that users wish to plot their sampling distribution
# 	nullObject:	A priori cutoffs for fit indices based on null hypothesis, saved in a vector
#	usedFit:		The name of fit indices that researchers wish to plot
#Description: 	This function will extract fit indices information and plot alternative sampling distributions with their cutoffs.
#Return: 		NONE. Just plot.
	
setMethod("plotPower", signature(altObject="data.frame", nullObject="data.frame"), definition=function(altObject, nullObject, alpha, usedFit=NULL) {
	percentile <- 1 - alpha
	cutoff <- getCutoff(nullObject, alpha)
	if(is.null(usedFit)) usedFit <- c("Chi", "AIC", "BIC", "RMSEA", "CFI", "TLI", "SRMR")
	altObject <- as.data.frame(altObject[,usedFit])
	nullObject <- as.data.frame(nullObject[,usedFit])
	colnames(altObject) <- colnames(nullObject) <- usedFit
	no.NA.altObject <- !apply(altObject, 2, is.na.vector)
	no.NA.nullObject <- !apply(nullObject, 2, is.na.vector)
	temp.name.alt <- colnames(altObject)[no.NA.altObject]
	temp.name.null <- colnames(nullObject)[no.NA.nullObject]
	altObject <- as.data.frame(altObject[,no.NA.altObject])
	nullObject <- as.data.frame(nullObject[,no.NA.nullObject])
	colnames(altObject) <- temp.name.alt
	colnames(nullObject) <- temp.name.null
	common.name <- intersect(colnames(altObject), colnames(nullObject))
	altObject <- as.data.frame(altObject[,common.name])
	nullObject <- as.data.frame(nullObject[,common.name])
	colnames(altObject) <- colnames(nullObject) <- common.name
	cutoff <- cutoff[common.name]
	if(length(common.name) == 2) {
		obj <- par(mfrow = c(1, 2))
	} else if(length(common.name) == 3) {
		obj <- par(mfrow = c(1, 3))
	} else if(length(common.name) > 3) {
		obj <- par(mfrow = c(2, ceiling(length(common.name)/2)))
	} else if(length(common.name) == 1) {
		# Intentionally leaving as blank
	} else {
		stop("Some errors occur")
	}
	for(i in 1:length(common.name)) {
		swap <- sum(common.name[i] == c("CFI", "TLI")) > 0
		overlap.hist(nullObject[,i], altObject[,i], main=common.name[i], xlab="Value", colors=c("yellow", "skyblue", "lightgreen"),
			swap=swap)
		cutoff1 <- quantile(nullObject[,i], percentile, na.rm = TRUE)
		abline(v = cutoff[i], lty=1, lwd=3)
		position <- "topright"
		if(swap) position <- "topleft"
		legend(position, c("Null","Alternative"), cex=1, bty="n", fill=c("yellow", "skyblue"))
	}
	if(length(common.name) > 1) par(obj)
})
#Arguments: 
#	altObject:		data.frame.c of alternative hypothesis that users wish to plot their sampling distribution
# 	nullObject:	data.frame.c of null hypothesis that users wish to plot their sampling distribution
#	alpha:			A priori alpha that users wish to find fit indices cutoffs.
#	usedFit:		The name of fit indices that researchers wish to plot
#Description: 	This function will plot overlapping sampling distributions with cutoffs.
#Return: 		NONE. Just plot.
	
setMethod("plotPower", signature(altObject="SimResult", nullObject="SimResult"), definition=function(altObject, nullObject, alpha, usedFit=NULL) {
	plotPower(altObject@fit, nullObject@fit, alpha, usedFit)
})
#Arguments: 
#	altObject:		SimResult.c of alternative hypothesis that users wish to plot their sampling distribution
# 	nullObject:	SimResult.c of null hypothesis that users wish to plot their sampling distribution
#	alpha:			A priori alpha that users wish to find fit indices cutoffs.
#	usedFit:		The name of fit indices that researchers wish to plot
#Description: 	This function will extract data.frame of fit indices values from SimResult.c and pass it to the same function for data.frame.c.
#Return: 		NONE. Just plot.
