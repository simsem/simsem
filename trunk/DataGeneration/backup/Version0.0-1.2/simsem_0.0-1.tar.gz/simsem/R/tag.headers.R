tag.headers <- function(object, ...) {}
setGeneric("tag.headers")
