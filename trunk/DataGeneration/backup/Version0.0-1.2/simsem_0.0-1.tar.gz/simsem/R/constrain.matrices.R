constrain.matrices <- function(object, simConstraint, ...) {}
setGeneric("constrain.matrices")
