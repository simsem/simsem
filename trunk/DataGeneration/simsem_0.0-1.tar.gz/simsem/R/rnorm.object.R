rnorm.object <-
function(Mean, SD) {
	temp <- new("Rnorm", Mean=Mean, SD=SD)
}

