runif.object <-
function(Lower, Upper) {
	temp <- new("Runif", Lower=Lower, Upper=Upper)
}

