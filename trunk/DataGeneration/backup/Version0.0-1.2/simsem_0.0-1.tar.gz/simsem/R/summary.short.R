summary.short <- function(object) {}
setGeneric("summary.short")