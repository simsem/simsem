setClass("Rnorm",
	representation(
		Mean="numeric",
		SD="numeric"
	)
)
