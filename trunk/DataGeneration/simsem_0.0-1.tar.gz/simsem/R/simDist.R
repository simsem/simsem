setClassUnion("simDist", c("Runif", "Rnorm"))
