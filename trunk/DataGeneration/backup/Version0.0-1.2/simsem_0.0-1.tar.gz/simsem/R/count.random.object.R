count.random.object <- function(object) {}
setGeneric("count.random.object")
