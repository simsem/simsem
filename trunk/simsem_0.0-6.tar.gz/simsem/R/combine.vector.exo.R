combine.vector.exo.endo <- function(exo, endo) {
	c(exo, endo)
}
