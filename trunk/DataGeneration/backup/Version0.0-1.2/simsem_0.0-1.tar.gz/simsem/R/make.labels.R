make.labels <- function(object, ...) {}
setGeneric("make.labels")
