# getPopulation: Description: Extract the population value from an object

getPopulation <- function(object) {
    return(object@paramValue)
} 
