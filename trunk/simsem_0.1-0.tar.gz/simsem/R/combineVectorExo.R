combineVectorExoEndo <- function(exo, endo) {
	c(exo, endo)
}
