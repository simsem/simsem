find.OpenMx.values <- function(Parameters, Starting.Values) {}
setGeneric("find.OpenMx.values")
