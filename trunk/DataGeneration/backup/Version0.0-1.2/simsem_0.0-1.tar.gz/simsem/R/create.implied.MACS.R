create.implied.MACS <- function(object) {}
setGeneric("create.implied.MACS")
