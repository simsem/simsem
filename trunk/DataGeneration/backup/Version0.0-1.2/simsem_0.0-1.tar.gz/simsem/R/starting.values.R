starting.values <- function(object, trial, ...) {}
setGeneric("starting.values") 
