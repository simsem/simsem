combine.object <- function(object1, object2, ...) {}
setGeneric("combine.object")
